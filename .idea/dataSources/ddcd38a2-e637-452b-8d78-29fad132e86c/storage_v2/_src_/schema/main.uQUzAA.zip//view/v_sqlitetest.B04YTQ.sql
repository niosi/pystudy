CREATE VIEW v_sqlitetest AS SELECT * FROM sqlitetest where name='li';

